package com.testing.tests;

import com.testing.base.BaseTest;
import com.testing.pages.LoginPage;

public class LoginTest extends BaseTest {

    public static void main(String[] args) {

        LoginTest test = new LoginTest();
        test.startBrowser();

        LoginPage login = new LoginPage(test.driver);
        login.clickLoginLink();
        login.enterEmail("test@gmail.com");
        login.enterPassword("test123");
        login.clickLoginButton();

        try {
            Thread.sleep(3000);
        } catch (Exception e) {}

        test.closeBrowser();
    }
}

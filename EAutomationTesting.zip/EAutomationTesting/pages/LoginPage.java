package com.testing.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void clickLoginLink() {
        driver.findElement(By.linkText("Log in")).click();
    }

    public void enterEmail(String email) {
        driver.findElement(By.id("Email")).sendKeys(email);
    }

    public void enterPassword(String password) {
        driver.findElement(By.id("Password")).sendKeys(password);
    }

    public void clickLoginButton() {
        driver.findElement(By.cssSelector("input[value='Log in']")).click();
    }
}
